# BASOYF Talent Assessment — Render deployment

## What this package contains
- Flask candidate assessment
- 40 MCQs + introduction
- Automatic score /100
- PostgreSQL database
- Recruiter dashboard
- CSV export
- Production Gunicorn start command
- Render Blueprint (`render.yaml`)

## Deploy with Render
1. Create a GitHub repository and upload all files in this folder to the repository root.
2. In Render, choose **New → Blueprint** and select the GitHub repository.
3. Render will read `render.yaml` and create the web service + PostgreSQL database.
4. When prompted for `ADMIN_PIN`, set a strong private PIN.
5. Deploy.
6. Open the generated `onrender.com` URL.
7. Candidate test: `/test`
8. Recruiter dashboard: `/admin`

## Important
- The included free Render database is intended for testing. Render currently states free services/datastores have limitations, and free Postgres databases expire after 30 days. Do not use the free tier as the permanent production database.
- Change `ADMIN_PIN` before sharing the recruiter dashboard.
- For real hiring use, add stronger authentication, CSRF protection, rate limiting, audit logs, privacy/retention controls, and validated AI evaluation for the introduction.
- Never put database passwords or secrets into source code. Render environment variables handle them.

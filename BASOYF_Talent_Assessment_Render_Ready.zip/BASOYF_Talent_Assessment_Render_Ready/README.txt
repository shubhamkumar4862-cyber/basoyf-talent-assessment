# BASOYF Talent Assessment Software

A complete local web application for an MNC-style candidate assessment.

## What it does
- Candidate test page
- 40 MCQs
- Introduction response
- 38-minute timer
- Automatic scoring out of 100
- Candidate result page
- Recruiter dashboard
- SQLite database
- CSV export

## Run on Windows / Mac
1. Install Python 3.10+.
2. Open Terminal / Command Prompt in this folder.
3. Run: `pip install flask`
4. Run: `python app.py`
5. Open: http://127.0.0.1:5000
6. Recruiter dashboard: http://127.0.0.1:5000/admin
7. Demo PIN: 2468

## Important before public use
- Change `app.secret_key`.
- Change `ADMIN_PIN`.
- Put the app behind HTTPS.
- Use a production database and proper authentication.
- Add server-side anti-cheating controls and rate limiting.
- Replace prototype introduction scoring with a validated AI evaluation system.